package com.openai.pocketrune;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends Activity {
    private RuneGameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        hideSystemUi();
        gameView = new RuneGameView(this);
        setContentView(gameView);
    }

    private void hideSystemUi() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (gameView != null) gameView.saveGame();
    }

    @Override
    public void onBackPressed() {
        if (gameView != null && gameView.handleBack()) return;
        super.onBackPressed();
    }

    private static final class RuneGameView extends View {
        private static final int MODE_TITLE = 0;
        private static final int MODE_WORLD = 1;
        private static final int MODE_BATTLE = 2;
        private static final int MODE_SHOP = 3;
        private static final int MODE_GAME_OVER = 4;
        private static final int MODE_VICTORY = 5;

        private static final int C_INK = Color.rgb(22, 21, 31);
        private static final int C_PANEL = Color.rgb(35, 34, 49);
        private static final int C_PANEL_2 = Color.rgb(47, 45, 62);
        private static final int C_PAPER = Color.rgb(239, 226, 188);
        private static final int C_GOLD = Color.rgb(222, 184, 82);
        private static final int C_RED = Color.rgb(185, 65, 70);
        private static final int C_GREEN = Color.rgb(72, 153, 91);
        private static final int C_BLUE = Color.rgb(70, 119, 178);
        private static final int C_PURPLE = Color.rgb(137, 82, 177);

        private final Paint paint = new Paint();
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Random random = new Random();
        private final SharedPreferences prefs;
        private final ArrayList<GameButton> buttons = new ArrayList<>();
        private final ArrayList<Particle> particles = new ArrayList<>();
        private final ArrayList<FloatingText> floatingTexts = new ArrayList<>();
        private final ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 45);

        private int mode = MODE_TITLE;
        private int level = 1;
        private int xp = 0;
        private int xpNeeded = 20;
        private int hp = 30;
        private int maxHp = 30;
        private int mana = 10;
        private int maxMana = 10;
        private int gold = 0;
        private int shards = 0;
        private int potions = 2;
        private int swordRank = 0;
        private int armorRank = 0;
        private int victories = 0;
        private int bestLevel = 1;
        private boolean hasSave = false;
        private boolean guarding = false;
        private Enemy enemy;
        private String headline = "THE WHISPERING ROAD";
        private String message = "Five rune shards can reopen the ancient gate. Find them before the Hollow King wakes.";
        private String toast = "";
        private long toastUntil = 0L;
        private long lastFrame = System.nanoTime();
        private float animationTime = 0f;
        private float shake = 0f;
        private float flash = 0f;
        private float heroAttack = 0f;
        private float enemyAttack = 0f;
        private int region = 0;

        RuneGameView(Context context) {
            super(context);
            setFocusable(true);
            setKeepScreenOn(true);
            paint.setAntiAlias(false);
            textPaint.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD));
            prefs = context.getSharedPreferences("pocket_rune_save", Context.MODE_PRIVATE);
            hasSave = prefs.getBoolean("has_save", false);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            long now = System.nanoTime();
            float dt = Math.min(0.04f, (now - lastFrame) / 1_000_000_000f);
            lastFrame = now;
            animationTime += dt;
            updateEffects(dt);

            canvas.save();
            if (shake > 0f) {
                canvas.translate((random.nextFloat() - 0.5f) * shake,
                        (random.nextFloat() - 0.5f) * shake);
            }

            buttons.clear();
            if (mode == MODE_TITLE) {
                drawTitle(canvas);
            } else {
                drawGame(canvas);
            }
            drawParticles(canvas);
            drawFloatingTexts(canvas);
            if (flash > 0f) {
                paint.setColor(Color.argb((int) (flash * 120), 255, 255, 255));
                canvas.drawRect(0, 0, getWidth(), getHeight(), paint);
            }
            canvas.restore();

            if (!toast.isEmpty() && System.currentTimeMillis() < toastUntil) {
                drawToast(canvas, toast);
            }
            postInvalidateOnAnimation();
        }

        private void updateEffects(float dt) {
            shake = Math.max(0f, shake - dt * 45f);
            flash = Math.max(0f, flash - dt * 2.8f);
            heroAttack = Math.max(0f, heroAttack - dt * 3.8f);
            enemyAttack = Math.max(0f, enemyAttack - dt * 3.3f);

            Iterator<Particle> it = particles.iterator();
            while (it.hasNext()) {
                Particle p = it.next();
                p.life -= dt;
                p.x += p.vx * dt;
                p.y += p.vy * dt;
                p.vy += 130f * dt;
                if (p.life <= 0f) it.remove();
            }
            Iterator<FloatingText> ft = floatingTexts.iterator();
            while (ft.hasNext()) {
                FloatingText f = ft.next();
                f.life -= dt;
                f.y -= 38f * dt;
                if (f.life <= 0f) ft.remove();
            }
        }

        private void drawTitle(Canvas c) {
            int w = getWidth();
            int h = getHeight();
            drawNightForest(c, 0);

            for (int i = 0; i < 34; i++) {
                float x = ((i * 97f) + animationTime * (5f + i % 4)) % w;
                float y = (i * 61f) % (h * 0.62f);
                float a = 0.35f + 0.65f * (float) Math.abs(Math.sin(animationTime * 1.2f + i));
                paint.setColor(Color.argb((int) (a * 190), 237, 218, 132));
                c.drawRect(x, y, x + 3, y + 3, paint);
            }

            float runeY = h * 0.22f + (float) Math.sin(animationTime * 1.5f) * 8f;
            drawRuneGate(c, w * 0.5f, runeY, Math.min(w, h) * 0.23f, true);

            drawCenteredText(c, "POCKET RUNE", h * 0.46f, Math.min(54f, w * 0.115f), C_PAPER);
            drawCenteredText(c, "R P G", h * 0.515f, Math.min(28f, w * 0.06f), C_GOLD);
            drawCenteredText(c, "A tiny adventure with surprisingly rude monsters",
                    h * 0.565f, Math.min(17f, w * 0.038f), Color.rgb(196, 190, 204));

            float bw = Math.min(w * 0.72f, 420f);
            float bh = Math.max(54f, h * 0.065f);
            float x = (w - bw) / 2f;
            float y = h * 0.66f;
            if (hasSave) {
                addButton(c, "CONTINUE", x, y, bw, bh, C_GOLD, "continue");
                addButton(c, "NEW ADVENTURE", x, y + bh + 14f, bw, bh, C_PANEL_2, "new");
            } else {
                addButton(c, "BEGIN ADVENTURE", x, y, bw, bh, C_GOLD, "new");
            }
            drawCenteredText(c, "Offline • No ads • Autosaves locally",
                    h * 0.91f, Math.min(14f, w * 0.032f), Color.rgb(156, 151, 168));
        }

        private void drawGame(Canvas c) {
            int w = getWidth();
            int h = getHeight();
            drawRegion(c, region);

            float sceneBottom = h * 0.56f;
            float heroX = w * 0.25f + (heroAttack > 0f ? (1f - Math.abs(heroAttack - 0.5f) * 2f) * 48f : 0f);
            float enemyX = w * 0.74f - (enemyAttack > 0f ? (1f - Math.abs(enemyAttack - 0.5f) * 2f) * 36f : 0f);
            float bob = (float) Math.sin(animationTime * 3.1f) * 3f;

            drawHero(c, heroX, sceneBottom + bob, Math.max(3.2f, w / 122f));
            if (mode == MODE_BATTLE && enemy != null) {
                drawEnemy(c, enemy, enemyX, sceneBottom + bob, Math.max(3.1f, w / 126f));
            } else if (mode == MODE_VICTORY) {
                drawRuneGate(c, w * 0.74f, sceneBottom - 90f, Math.min(w, h) * 0.18f, false);
            } else {
                drawCampProps(c, w * 0.73f, sceneBottom);
            }

            drawHud(c);
            drawMessagePanel(c);

            if (mode == MODE_WORLD) drawWorldControls(c);
            else if (mode == MODE_BATTLE) drawBattleControls(c);
            else if (mode == MODE_SHOP) drawShop(c);
            else if (mode == MODE_GAME_OVER) drawGameOver(c);
            else if (mode == MODE_VICTORY) drawVictory(c);
        }

        private void drawRegion(Canvas c, int r) {
            if (r == 0) drawNightForest(c, 0);
            else if (r == 1) drawMoonCaves(c);
            else if (r == 2) drawRuins(c);
            else drawThrone(c);
        }

        private void drawNightForest(Canvas c, int ignored) {
            int w = getWidth();
            int h = getHeight();
            paint.setColor(Color.rgb(22, 28, 52));
            c.drawRect(0, 0, w, h, paint);
            paint.setColor(Color.rgb(47, 58, 91));
            c.drawCircle(w * 0.78f, h * 0.14f, Math.min(w, h) * 0.085f, paint);
            paint.setColor(Color.rgb(22, 28, 52));
            c.drawCircle(w * 0.81f, h * 0.12f, Math.min(w, h) * 0.075f, paint);

            paint.setColor(Color.rgb(28, 45, 53));
            Path hill = new Path();
            hill.moveTo(0, h * 0.38f);
            hill.lineTo(w * 0.22f, h * 0.27f);
            hill.lineTo(w * 0.43f, h * 0.39f);
            hill.lineTo(w * 0.67f, h * 0.24f);
            hill.lineTo(w, h * 0.38f);
            hill.lineTo(w, h * 0.62f);
            hill.lineTo(0, h * 0.62f);
            hill.close();
            c.drawPath(hill, paint);

            paint.setColor(Color.rgb(18, 35, 37));
            for (int i = 0; i < 10; i++) {
                float x = i * (w / 9f) - 25f;
                float y = h * (0.33f + (i % 3) * 0.035f);
                drawPine(c, x, y, 45f + (i % 4) * 9f);
            }
            paint.setColor(Color.rgb(35, 48, 40));
            c.drawRect(0, h * 0.48f, w, h, paint);
            paint.setColor(Color.rgb(48, 61, 48));
            for (int i = 0; i < 22; i++) {
                float x = (i * 71f) % w;
                float y = h * 0.49f + (i % 5) * 17f;
                c.drawRect(x, y, x + 18, y + 5, paint);
            }
        }

        private void drawPine(Canvas c, float x, float y, float size) {
            Path p = new Path();
            p.moveTo(x, y - size);
            p.lineTo(x - size * 0.55f, y + size * 0.15f);
            p.lineTo(x - size * 0.18f, y + size * 0.05f);
            p.lineTo(x - size * 0.62f, y + size * 0.55f);
            p.lineTo(x + size * 0.62f, y + size * 0.55f);
            p.lineTo(x + size * 0.18f, y + size * 0.05f);
            p.lineTo(x + size * 0.55f, y + size * 0.15f);
            p.close();
            c.drawPath(p, paint);
        }

        private void drawMoonCaves(Canvas c) {
            int w = getWidth();
            int h = getHeight();
            paint.setColor(Color.rgb(26, 24, 43));
            c.drawRect(0, 0, w, h, paint);
            paint.setColor(Color.rgb(44, 40, 64));
            for (int i = 0; i < 14; i++) {
                float x = (i * 83f) % w;
                float top = (i % 3) * 22f;
                Path stal = new Path();
                stal.moveTo(x, top);
                stal.lineTo(x + 30, top);
                stal.lineTo(x + 12, h * (0.12f + (i % 4) * 0.025f));
                stal.close();
                c.drawPath(stal, paint);
            }
            paint.setColor(Color.rgb(46, 52, 63));
            c.drawRect(0, h * 0.46f, w, h, paint);
            for (int i = 0; i < 8; i++) {
                float x = (i + 0.5f) * w / 8f;
                float y = h * (0.29f + (i % 2) * 0.04f);
                paint.setColor(Color.rgb(67, 114, 143));
                Path crystal = new Path();
                crystal.moveTo(x, y - 42);
                crystal.lineTo(x - 16, y);
                crystal.lineTo(x - 8, y + 28);
                crystal.lineTo(x + 13, y + 21);
                crystal.lineTo(x + 18, y - 3);
                crystal.close();
                c.drawPath(crystal, paint);
                paint.setColor(Color.argb(40, 113, 208, 255));
                c.drawCircle(x, y, 52, paint);
            }
        }

        private void drawRuins(Canvas c) {
            int w = getWidth();
            int h = getHeight();
            paint.setColor(Color.rgb(55, 54, 70));
            c.drawRect(0, 0, w, h, paint);
            paint.setColor(Color.rgb(76, 74, 86));
            for (int i = 0; i < 7; i++) {
                float x = i * w / 6f - 18f;
                c.drawRect(x, h * 0.16f, x + 36, h * 0.48f, paint);
                c.drawRect(x - 14, h * 0.14f, x + 50, h * 0.18f, paint);
            }
            paint.setColor(Color.rgb(64, 69, 60));
            c.drawRect(0, h * 0.47f, w, h, paint);
            paint.setColor(Color.rgb(92, 94, 82));
            for (int i = 0; i < 20; i++) {
                float x = (i * 67f) % w;
                float y = h * 0.48f + (i % 4) * 22f;
                c.drawRect(x, y, x + 30, y + 7, paint);
            }
            paint.setColor(Color.argb(90, 168, 190, 204));
            for (int i = 0; i < 35; i++) {
                float x = ((i * 59f) + animationTime * 90f) % (w + 80) - 40;
                float y = ((i * 37f) + animationTime * 180f) % (h * 0.56f);
                c.drawRect(x, y, x + 2, y + 14, paint);
            }
        }

        private void drawThrone(Canvas c) {
            int w = getWidth();
            int h = getHeight();
            paint.setColor(Color.rgb(24, 18, 31));
            c.drawRect(0, 0, w, h, paint);
            paint.setColor(Color.rgb(55, 35, 63));
            for (int i = 0; i < 8; i++) {
                float x = i * w / 7f;
                c.drawRect(x, h * 0.08f, x + 18, h * 0.49f, paint);
            }
            paint.setColor(Color.rgb(45, 38, 48));
            c.drawRect(0, h * 0.47f, w, h, paint);
            paint.setColor(Color.rgb(86, 45, 66));
            Path carpet = new Path();
            carpet.moveTo(w * 0.4f, h * 0.47f);
            carpet.lineTo(w * 0.6f, h * 0.47f);
            carpet.lineTo(w * 0.88f, h);
            carpet.lineTo(w * 0.12f, h);
            carpet.close();
            c.drawPath(carpet, paint);
            for (int i = 0; i < 6; i++) {
                paint.setColor(Color.argb(60, 181, 69, 196));
                float x = (i + 1) * w / 7f;
                float y = h * 0.28f + (float) Math.sin(animationTime * 2f + i) * 12f;
                c.drawCircle(x, y, 12 + i % 2 * 5, paint);
            }
        }

        private void drawHud(Canvas c) {
            int w = getWidth();
            float pad = Math.max(12f, w * 0.025f);
            float top = pad;
            float panelH = Math.max(92f, getHeight() * 0.105f);
            drawPanel(c, pad, top, w - pad, top + panelH, C_PANEL, 18f);

            float portrait = panelH - 18f;
            drawHeroPortrait(c, pad + 9f, top + 9f, portrait);
            float left = pad + portrait + 20f;
            float right = w - pad - 12f;

            textPaint.setTextAlign(Paint.Align.LEFT);
            drawText(c, "LV " + level, left, top + 25f, 18f, C_PAPER);
            textPaint.setTextAlign(Paint.Align.RIGHT);
            drawText(c, gold + " G", right, top + 25f, 17f, C_GOLD);
            textPaint.setTextAlign(Paint.Align.LEFT);

            float barW = right - left;
            drawBar(c, left, top + 35f, barW, 13f, hp, maxHp, C_RED,
                    "HP " + hp + "/" + maxHp);
            drawBar(c, left, top + 56f, barW, 10f, mana, maxMana, C_BLUE,
                    "MP " + mana + "/" + maxMana);
            drawBar(c, left, top + 74f, barW, 8f, xp, xpNeeded, C_GOLD,
                    "XP " + xp + "/" + xpNeeded);

            if (mode == MODE_BATTLE && enemy != null) {
                float ey = top + panelH + 8f;
                float ew = w - pad * 2;
                drawPanel(c, pad, ey, w - pad, ey + 42f, C_PANEL, 14f);
                textPaint.setTextAlign(Paint.Align.LEFT);
                drawText(c, enemy.name, pad + 12f, ey + 19f, 16f, C_PAPER);
                textPaint.setTextAlign(Paint.Align.RIGHT);
                drawText(c, enemy.boss ? "BOSS" : "LV " + enemy.level,
                        w - pad - 12f, ey + 19f, 14f, enemy.boss ? C_PURPLE : C_GOLD);
                textPaint.setTextAlign(Paint.Align.LEFT);
                drawBar(c, pad + 12f, ey + 26f, ew - 24f, 8f,
                        Math.max(0, enemy.hp), enemy.maxHp, enemy.boss ? C_PURPLE : C_RED, "");
            }
        }

        private void drawHeroPortrait(Canvas c, float x, float y, float size) {
            paint.setColor(Color.rgb(20, 24, 35));
            c.drawRect(x, y, x + size, y + size, paint);
            float s = size / 12f;
            pixel(c, x, y, s, 3, 1, 6, 2, Color.rgb(193, 198, 206));
            pixel(c, x, y, s, 2, 3, 8, 5, Color.rgb(109, 119, 139));
            pixel(c, x, y, s, 3, 4, 2, 1, Color.rgb(235, 199, 148));
            pixel(c, x, y, s, 7, 4, 2, 1, Color.rgb(235, 199, 148));
            pixel(c, x, y, s, 4, 6, 4, 4, Color.rgb(68, 92, 137));
            pixel(c, x, y, s, 3, 9, 6, 2, Color.rgb(43, 52, 78));
        }

        private void drawBar(Canvas c, float x, float y, float w, float h,
                             int value, int max, int color, String label) {
            paint.setColor(Color.rgb(18, 18, 27));
            c.drawRoundRect(new RectF(x, y, x + w, y + h), h / 2f, h / 2f, paint);
            float ratio = max <= 0 ? 0 : Math.max(0f, Math.min(1f, value / (float) max));
            paint.setColor(color);
            c.drawRoundRect(new RectF(x + 2, y + 2, x + 2 + (w - 4) * ratio, y + h - 2),
                    Math.max(1f, h / 2f - 2), Math.max(1f, h / 2f - 2), paint);
            if (!label.isEmpty()) {
                textPaint.setTextAlign(Paint.Align.CENTER);
                drawText(c, label, x + w / 2f, y + h - 1f, Math.max(9f, h * 0.78f), Color.WHITE);
                textPaint.setTextAlign(Paint.Align.LEFT);
            }
        }

        private void drawMessagePanel(Canvas c) {
            int w = getWidth();
            int h = getHeight();
            float pad = Math.max(12f, w * 0.025f);
            float y = h * 0.59f;
            float bottom = h * 0.735f;
            drawPanel(c, pad, y, w - pad, bottom, C_PANEL, 18f);
            drawText(c, headline, pad + 16f, y + 27f, Math.min(19f, w * 0.043f), C_GOLD);
            drawWrappedText(c, message, pad + 16f, y + 53f, w - pad * 2 - 32f,
                    Math.min(16f, w * 0.037f), Color.rgb(218, 213, 224), 1.25f, 3);

            float badgeY = bottom - 24f;
            drawSmallBadge(c, "◆ " + shards + "/5", pad + 16f, badgeY, C_PURPLE);
            drawSmallBadge(c, "⚗ " + potions, pad + 94f, badgeY, C_GREEN);
            drawSmallBadge(c, "⚔ +" + swordRank, pad + 159f, badgeY, C_RED);
            drawSmallBadge(c, "▣ +" + armorRank, pad + 231f, badgeY, C_BLUE);
        }

        private void drawSmallBadge(Canvas c, String value, float x, float baseline, int color) {
            textPaint.setTextSize(13f);
            float width = textPaint.measureText(value) + 14f;
            paint.setColor(Color.argb(95, Color.red(color), Color.green(color), Color.blue(color)));
            c.drawRoundRect(new RectF(x, baseline - 17f, x + width, baseline + 3f), 10f, 10f, paint);
            drawText(c, value, x + 7f, baseline - 1f, 13f, Color.WHITE);
        }

        private void drawWorldControls(Canvas c) {
            int w = getWidth();
            int h = getHeight();
            float pad = Math.max(12f, w * 0.025f);
            float gap = 10f;
            float y = h * 0.76f;
            float bw = (w - pad * 2 - gap) / 2f;
            float bh = Math.max(54f, h * 0.075f);
            addButton(c, "EXPLORE", pad, y, bw, bh, C_GOLD, "explore");
            addButton(c, "REST  8G", pad + bw + gap, y, bw, bh,
                    hp < maxHp && gold >= 8 ? C_GREEN : C_PANEL_2, "rest");
            addButton(c, "SHOP", pad, y + bh + gap, bw, bh, C_BLUE, "shop");
            String gate = shards >= 5 ? "ENTER RUNE GATE" : "GATE  " + shards + "/5";
            addButton(c, gate, pad + bw + gap, y + bh + gap, bw, bh,
                    shards >= 5 ? C_PURPLE : C_PANEL_2, "gate");
        }

        private void drawBattleControls(Canvas c) {
            int w = getWidth();
            int h = getHeight();
            float pad = Math.max(10f, w * 0.022f);
            float gap = 8f;
            float y = h * 0.755f;
            float bw = (w - pad * 2 - gap) / 2f;
            float bh = Math.max(52f, h * 0.069f);
            addButton(c, "⚔  ATTACK", pad, y, bw, bh, C_RED, "attack");
            addButton(c, "✦  ARC BOLT  3MP", pad + bw + gap, y, bw, bh,
                    mana >= 3 ? C_BLUE : C_PANEL_2, "spell");
            addButton(c, "▣  GUARD", pad, y + bh + gap, bw, bh, C_GREEN, "guard");
            addButton(c, "⚗  POTION  " + potions, pad + bw + gap, y + bh + gap, bw, bh,
                    potions > 0 ? C_PURPLE : C_PANEL_2, "potion");
            float fleeW = Math.min(w * 0.48f, 280f);
            addButton(c, enemy != null && enemy.boss ? "NO ESCAPE" : "FLEE",
                    (w - fleeW) / 2f, y + (bh + gap) * 2, fleeW, Math.max(42f, bh * 0.74f),
                    C_PANEL_2, "flee");
        }

        private void drawShop(Canvas c) {
            int w = getWidth();
            int h = getHeight();
            float pad = Math.max(12f, w * 0.025f);
            float y = h * 0.755f;
            float gap = 8f;
            float bh = Math.max(48f, h * 0.06f);
            int swordCost = 12 + swordRank * 10;
            int armorCost = 14 + armorRank * 11;
            addButton(c, "SWORD +1   " + swordCost + "G", pad, y, w - pad * 2, bh,
                    gold >= swordCost ? C_RED : C_PANEL_2, "buy_sword");
            addButton(c, "ARMOR +1   " + armorCost + "G", pad, y + bh + gap,
                    w - pad * 2, bh, gold >= armorCost ? C_BLUE : C_PANEL_2, "buy_armor");
            float bw = (w - pad * 2 - gap) / 2f;
            addButton(c, "POTION   6G", pad, y + (bh + gap) * 2, bw, bh,
                    gold >= 6 ? C_GREEN : C_PANEL_2, "buy_potion");
            addButton(c, "BACK", pad + bw + gap, y + (bh + gap) * 2, bw, bh,
                    C_GOLD, "back_world");
        }

        private void drawGameOver(Canvas c) {
            int w = getWidth();
            int h = getHeight();
            paint.setColor(Color.argb(150, 12, 8, 14));
            c.drawRect(0, 0, w, h, paint);
            drawPanel(c, w * 0.08f, h * 0.27f, w * 0.92f, h * 0.62f, C_PANEL, 24f);
            drawCenteredText(c, "YOU HAVE FALLEN", h * 0.35f, Math.min(32f, w * 0.07f), C_RED);
            drawCenteredText(c, "Level " + level + "  •  " + shards + "/5 shards",
                    h * 0.41f, 18f, C_PAPER);
            drawCenteredText(c, "The monsters immediately spend your gold on snacks.",
                    h * 0.46f, 15f, Color.rgb(190, 184, 198));
            addButton(c, "TRY AGAIN", w * 0.18f, h * 0.515f, w * 0.64f,
                    Math.max(56f, h * 0.07f), C_GOLD, "restart");
        }

        private void drawVictory(Canvas c) {
            int w = getWidth();
            int h = getHeight();
            paint.setColor(Color.argb(95, 45, 27, 72));
            c.drawRect(0, 0, w, h, paint);
            drawPanel(c, w * 0.06f, h * 0.25f, w * 0.94f, h * 0.63f, C_PANEL, 24f);
            drawCenteredText(c, "THE REALM IS SAVED", h * 0.33f,
                    Math.min(31f, w * 0.068f), C_GOLD);
            drawCenteredText(c, "You defeated the Hollow King at level " + level + ".",
                    h * 0.39f, 17f, C_PAPER);
            drawCenteredText(c, "Several villagers claim they helped.",
                    h * 0.435f, 15f, Color.rgb(190, 184, 198));
            drawCenteredText(c, "Best level: " + Math.max(bestLevel, level),
                    h * 0.48f, 15f, C_PURPLE);
            addButton(c, "NEW ADVENTURE +", w * 0.17f, h * 0.535f, w * 0.66f,
                    Math.max(56f, h * 0.07f), C_PURPLE, "new_plus");
        }

        private void drawHero(Canvas c, float x, float ground, float s) {
            float baseX = x - 8f * s;
            float baseY = ground - 20f * s;
            int skin = Color.rgb(232, 187, 137);
            int steel = Color.rgb(149, 160, 177);
            int darkSteel = Color.rgb(74, 83, 107);
            int cloak = Color.rgb(57, 85, 135);
            int boot = Color.rgb(46, 37, 46);

            pixel(c, baseX, baseY, s, 5, 0, 6, 2, steel);
            pixel(c, baseX, baseY, s, 3, 2, 10, 5, darkSteel);
            pixel(c, baseX, baseY, s, 4, 3, 2, 1, skin);
            pixel(c, baseX, baseY, s, 10, 3, 2, 1, skin);
            pixel(c, baseX, baseY, s, 5, 4, 2, 1, C_INK);
            pixel(c, baseX, baseY, s, 9, 4, 2, 1, C_INK);
            pixel(c, baseX, baseY, s, 5, 7, 6, 6, steel);
            pixel(c, baseX, baseY, s, 4, 8, 2, 7, cloak);
            pixel(c, baseX, baseY, s, 10, 8, 2, 7, cloak);
            pixel(c, baseX, baseY, s, 6, 10, 4, 2, C_GOLD);
            pixel(c, baseX, baseY, s, 6, 13, 2, 5, darkSteel);
            pixel(c, baseX, baseY, s, 9, 13, 2, 5, darkSteel);
            pixel(c, baseX, baseY, s, 5, 18, 3, 2, boot);
            pixel(c, baseX, baseY, s, 9, 18, 3, 2, boot);

            float swordX = baseX + 12f * s;
            float swordY = baseY + 8f * s;
            paint.setColor(Color.rgb(224, 228, 235));
            c.save();
            c.rotate(heroAttack > 0f ? -55f : -18f, swordX, swordY);
            c.drawRect(swordX, swordY - 9f * s, swordX + 1.6f * s, swordY + 8f * s, paint);
            paint.setColor(C_GOLD);
            c.drawRect(swordX - 2f * s, swordY + 5f * s, swordX + 4f * s, swordY + 7f * s, paint);
            c.restore();
        }

        private void drawEnemy(Canvas c, Enemy e, float x, float ground, float s) {
            switch (e.type) {
                case 0: drawSlime(c, x, ground, s); break;
                case 1: drawWolf(c, x, ground, s); break;
                case 2: drawGoblin(c, x, ground, s); break;
                case 3: drawWraith(c, x, ground, s); break;
                case 4: drawGolem(c, x, ground, s); break;
                default: drawKing(c, x, ground, s); break;
            }
        }

        private void drawSlime(Canvas c, float x, float ground, float s) {
            float wobble = 1f + (float) Math.sin(animationTime * 4f) * 0.05f;
            float bx = x - 9 * s;
            float by = ground - 12 * s;
            int body = Color.rgb(79, 168, 118);
            pixel(c, bx, by, s * wobble, 3, 1, 12, 2, body);
            pixel(c, bx, by, s * wobble, 1, 3, 16, 7, body);
            pixel(c, bx, by, s * wobble, 3, 10, 12, 2, body);
            pixel(c, bx, by, s * wobble, 4, 5, 2, 2, C_INK);
            pixel(c, bx, by, s * wobble, 12, 5, 2, 2, C_INK);
            pixel(c, bx, by, s * wobble, 7, 8, 4, 1, Color.rgb(39, 92, 65));
        }

        private void drawWolf(Canvas c, float x, float ground, float s) {
            float bx = x - 12 * s;
            float by = ground - 14 * s;
            int fur = Color.rgb(118, 126, 145);
            int dark = Color.rgb(58, 62, 78);
            pixel(c, bx, by, s, 3, 5, 13, 7, fur);
            pixel(c, bx, by, s, 12, 2, 8, 8, fur);
            pixel(c, bx, by, s, 14, 0, 2, 3, dark);
            pixel(c, bx, by, s, 18, 0, 2, 3, dark);
            pixel(c, bx, by, s, 17, 4, 2, 2, C_RED);
            pixel(c, bx, by, s, 20, 7, 3, 2, dark);
            pixel(c, bx, by, s, 4, 11, 3, 4, dark);
            pixel(c, bx, by, s, 13, 11, 3, 4, dark);
            pixel(c, bx, by, s, 0, 4, 5, 3, fur);
        }

        private void drawGoblin(Canvas c, float x, float ground, float s) {
            float bx = x - 9 * s;
            float by = ground - 20 * s;
            int green = Color.rgb(113, 151, 69);
            pixel(c, bx, by, s, 4, 1, 9, 7, green);
            pixel(c, bx, by, s, 1, 2, 4, 2, green);
            pixel(c, bx, by, s, 12, 2, 4, 2, green);
            pixel(c, bx, by, s, 5, 3, 2, 2, C_INK);
            pixel(c, bx, by, s, 10, 3, 2, 2, C_INK);
            pixel(c, bx, by, s, 5, 8, 8, 7, Color.rgb(104, 67, 53));
            pixel(c, bx, by, s, 3, 9, 2, 7, green);
            pixel(c, bx, by, s, 13, 9, 2, 7, green);
            pixel(c, bx, by, s, 6, 15, 2, 5, Color.rgb(58, 51, 48));
            pixel(c, bx, by, s, 10, 15, 2, 5, Color.rgb(58, 51, 48));
            paint.setColor(Color.rgb(184, 169, 126));
            c.drawRect(bx + 14 * s, by + 6 * s, bx + 16 * s, by + 18 * s, paint);
            c.drawCircle(bx + 15 * s, by + 6 * s, 3 * s, paint);
        }

        private void drawWraith(Canvas c, float x, float ground, float s) {
            float bx = x - 10 * s;
            float by = ground - 23 * s + (float) Math.sin(animationTime * 2.5f) * 5f;
            int robe = Color.rgb(93, 74, 130);
            paint.setColor(Color.argb(50, 175, 108, 222));
            c.drawCircle(x, by + 12 * s, 15 * s, paint);
            pixel(c, bx, by, s, 5, 0, 10, 4, Color.rgb(45, 39, 59));
            pixel(c, bx, by, s, 3, 4, 14, 11, robe);
            pixel(c, bx, by, s, 1, 14, 18, 5, robe);
            pixel(c, bx, by, s, 4, 19, 3, 3, robe);
            pixel(c, bx, by, s, 9, 18, 3, 4, robe);
            pixel(c, bx, by, s, 14, 19, 3, 3, robe);
            pixel(c, bx, by, s, 7, 6, 2, 2, Color.rgb(192, 110, 237));
            pixel(c, bx, by, s, 12, 6, 2, 2, Color.rgb(192, 110, 237));
        }

        private void drawGolem(Canvas c, float x, float ground, float s) {
            float bx = x - 12 * s;
            float by = ground - 24 * s;
            int stone = Color.rgb(118, 112, 105);
            int dark = Color.rgb(77, 71, 70);
            pixel(c, bx, by, s, 6, 0, 12, 7, stone);
            pixel(c, bx, by, s, 3, 7, 18, 12, stone);
            pixel(c, bx, by, s, 0, 8, 5, 11, dark);
            pixel(c, bx, by, s, 20, 8, 5, 11, dark);
            pixel(c, bx, by, s, 5, 19, 6, 5, dark);
            pixel(c, bx, by, s, 14, 19, 6, 5, dark);
            pixel(c, bx, by, s, 9, 3, 2, 2, C_GOLD);
            pixel(c, bx, by, s, 14, 3, 2, 2, C_GOLD);
            pixel(c, bx, by, s, 8, 11, 9, 2, Color.rgb(75, 125, 135));
        }

        private void drawKing(Canvas c, float x, float ground, float s) {
            float bx = x - 12 * s;
            float by = ground - 28 * s + (float) Math.sin(animationTime * 2f) * 3f;
            paint.setColor(Color.argb(65, 183, 69, 210));
            c.drawCircle(x, by + 12 * s, 24 * s, paint);
            pixel(c, bx, by, s, 6, 0, 13, 4, C_GOLD);
            pixel(c, bx, by, s, 8, -3, 2, 4, C_GOLD);
            pixel(c, bx, by, s, 13, -4, 2, 5, C_GOLD);
            pixel(c, bx, by, s, 18, -3, 2, 4, C_GOLD);
            pixel(c, bx, by, s, 5, 4, 15, 8, Color.rgb(42, 38, 48));
            pixel(c, bx, by, s, 3, 12, 19, 12, Color.rgb(62, 44, 70));
            pixel(c, bx, by, s, 0, 13, 5, 11, Color.rgb(38, 33, 43));
            pixel(c, bx, by, s, 21, 13, 5, 11, Color.rgb(38, 33, 43));
            pixel(c, bx, by, s, 5, 24, 5, 4, Color.rgb(38, 33, 43));
            pixel(c, bx, by, s, 15, 24, 5, 4, Color.rgb(38, 33, 43));
            pixel(c, bx, by, s, 8, 7, 2, 2, Color.rgb(224, 83, 211));
            pixel(c, bx, by, s, 15, 7, 2, 2, Color.rgb(224, 83, 211));
            pixel(c, bx, by, s, 11, 16, 4, 4, C_PURPLE);
        }

        private void drawCampProps(Canvas c, float x, float ground) {
            float s = Math.max(2.4f, getWidth() / 160f);
            paint.setColor(Color.rgb(82, 55, 43));
            c.drawRect(x - 14 * s, ground - 3 * s, x + 14 * s, ground, paint);
            c.save();
            c.rotate(20, x, ground);
            c.drawRect(x - 10 * s, ground - 2 * s, x + 10 * s, ground + 1 * s, paint);
            c.restore();
            paint.setColor(Color.rgb(225, 95, 45));
            Path flame = new Path();
            flame.moveTo(x, ground - 16 * s);
            flame.lineTo(x - 6 * s, ground - 3 * s);
            flame.lineTo(x, ground - 7 * s);
            flame.lineTo(x + 6 * s, ground - 3 * s);
            flame.close();
            c.drawPath(flame, paint);
            paint.setColor(C_GOLD);
            Path inner = new Path();
            inner.moveTo(x, ground - 12 * s);
            inner.lineTo(x - 3 * s, ground - 3 * s);
            inner.lineTo(x + 3 * s, ground - 3 * s);
            inner.close();
            c.drawPath(inner, paint);
        }

        private void drawRuneGate(Canvas c, float cx, float cy, float size, boolean glow) {
            if (glow) {
                paint.setColor(Color.argb(35, 176, 83, 217));
                c.drawCircle(cx, cy, size * 0.72f, paint);
            }
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(5f, size * 0.055f));
            paint.setColor(Color.rgb(119, 105, 124));
            RectF arch = new RectF(cx - size * 0.45f, cy - size * 0.5f,
                    cx + size * 0.45f, cy + size * 0.45f);
            c.drawArc(arch, 180, 180, false, paint);
            c.drawLine(cx - size * 0.45f, cy, cx - size * 0.45f, cy + size * 0.45f, paint);
            c.drawLine(cx + size * 0.45f, cy, cx + size * 0.45f, cy + size * 0.45f, paint);
            paint.setStrokeWidth(Math.max(3f, size * 0.025f));
            paint.setColor(C_PURPLE);
            for (int i = 0; i < 5; i++) {
                double a = Math.PI + i * Math.PI / 4.0;
                float rx = cx + (float) Math.cos(a) * size * 0.45f;
                float ry = cy + (float) Math.sin(a) * size * 0.45f;
                c.drawCircle(rx, ry, size * 0.055f, paint);
            }
            paint.setStyle(Paint.Style.FILL);
        }

        private void pixel(Canvas c, float x, float y, float s,
                           int px, int py, int pw, int ph, int color) {
            paint.setColor(color);
            c.drawRect(x + px * s, y + py * s, x + (px + pw) * s, y + (py + ph) * s, paint);
        }

        private void drawPanel(Canvas c, float l, float t, float r, float b, int color, float radius) {
            paint.setColor(Color.argb(220, Color.red(color), Color.green(color), Color.blue(color)));
            c.drawRoundRect(new RectF(l, t, r, b), radius, radius, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2f);
            paint.setColor(Color.argb(135, 190, 179, 208));
            c.drawRoundRect(new RectF(l + 1, t + 1, r - 1, b - 1), radius, radius, paint);
            paint.setStyle(Paint.Style.FILL);
        }

        private void addButton(Canvas c, String label, float x, float y, float w, float h,
                               int color, String action) {
            RectF rect = new RectF(x, y, x + w, y + h);
            buttons.add(new GameButton(rect, action));
            paint.setColor(color);
            c.drawRoundRect(rect, Math.min(16f, h * 0.22f), Math.min(16f, h * 0.22f), paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2f);
            paint.setColor(Color.argb(160, 240, 232, 211));
            c.drawRoundRect(new RectF(x + 1, y + 1, x + w - 1, y + h - 1),
                    Math.min(16f, h * 0.22f), Math.min(16f, h * 0.22f), paint);
            paint.setStyle(Paint.Style.FILL);
            textPaint.setTextAlign(Paint.Align.CENTER);
            drawText(c, label, x + w / 2f, y + h / 2f + 6f,
                    Math.min(18f, Math.max(13f, w / Math.max(8f, label.length() * 0.72f))),
                    color == C_GOLD ? C_INK : Color.WHITE);
            textPaint.setTextAlign(Paint.Align.LEFT);
        }

        private void drawText(Canvas c, String text, float x, float baseline, float size, int color) {
            textPaint.setTextSize(size);
            textPaint.setColor(color);
            c.drawText(text, x, baseline, textPaint);
        }

        private void drawCenteredText(Canvas c, String text, float baseline, float size, int color) {
            textPaint.setTextAlign(Paint.Align.CENTER);
            drawText(c, text, getWidth() / 2f, baseline, size, color);
            textPaint.setTextAlign(Paint.Align.LEFT);
        }

        private void drawWrappedText(Canvas c, String text, float x, float y, float maxWidth,
                                     float size, int color, float lineSpacing, int maxLines) {
            textPaint.setTextSize(size);
            textPaint.setColor(color);
            textPaint.setTextAlign(Paint.Align.LEFT);
            String[] words = text.split(" ");
            StringBuilder line = new StringBuilder();
            int lines = 0;
            for (String word : words) {
                String test = line.length() == 0 ? word : line + " " + word;
                if (textPaint.measureText(test) > maxWidth && line.length() > 0) {
                    c.drawText(line.toString(), x, y + lines * size * lineSpacing, textPaint);
                    lines++;
                    if (lines >= maxLines) return;
                    line = new StringBuilder(word);
                } else {
                    line = new StringBuilder(test);
                }
            }
            if (line.length() > 0 && lines < maxLines) {
                c.drawText(line.toString(), x, y + lines * size * lineSpacing, textPaint);
            }
        }

        private void drawParticles(Canvas c) {
            for (Particle p : particles) {
                float alpha = Math.max(0f, Math.min(1f, p.life / p.maxLife));
                paint.setColor(Color.argb((int) (alpha * 255), Color.red(p.color),
                        Color.green(p.color), Color.blue(p.color)));
                c.drawRect(p.x, p.y, p.x + p.size, p.y + p.size, paint);
            }
        }

        private void drawFloatingTexts(Canvas c) {
            for (FloatingText f : floatingTexts) {
                textPaint.setTextAlign(Paint.Align.CENTER);
                int alpha = (int) (255 * Math.max(0f, Math.min(1f, f.life / f.maxLife)));
                int color = Color.argb(alpha, Color.red(f.color), Color.green(f.color), Color.blue(f.color));
                drawText(c, f.text, f.x, f.y, f.size, color);
            }
            textPaint.setTextAlign(Paint.Align.LEFT);
        }

        private void drawToast(Canvas c, String value) {
            textPaint.setTextSize(15f);
            float tw = textPaint.measureText(value) + 34f;
            float x = (getWidth() - tw) / 2f;
            float y = getHeight() * 0.52f;
            paint.setColor(Color.argb(235, 17, 16, 24));
            c.drawRoundRect(new RectF(x, y, x + tw, y + 42f), 21f, 21f, paint);
            textPaint.setTextAlign(Paint.Align.CENTER);
            drawText(c, value, getWidth() / 2f, y + 27f, 15f, C_PAPER);
            textPaint.setTextAlign(Paint.Align.LEFT);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (event.getAction() != MotionEvent.ACTION_UP) return true;
            float x = event.getX();
            float y = event.getY();
            for (int i = buttons.size() - 1; i >= 0; i--) {
                GameButton b = buttons.get(i);
                if (b.rect.contains(x, y)) {
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                    handleAction(b.action);
                    return true;
                }
            }
            return true;
        }

        private void handleAction(String action) {
            switch (action) {
                case "continue": loadGame(); mode = MODE_WORLD; break;
                case "new": newGame(false); break;
                case "new_plus": newGame(true); break;
                case "explore": explore(); break;
                case "rest": rest(); break;
                case "shop": openShop(); break;
                case "gate": enterGate(); break;
                case "attack": attack(); break;
                case "spell": castSpell(); break;
                case "guard": guard(); break;
                case "potion": usePotion(); break;
                case "flee": flee(); break;
                case "buy_sword": buySword(); break;
                case "buy_armor": buyArmor(); break;
                case "buy_potion": buyPotion(); break;
                case "back_world": mode = MODE_WORLD; setWorldMessage(); break;
                case "restart": newGame(false); break;
            }
            invalidate();
        }

        private void newGame(boolean plus) {
            int bonus = plus ? Math.min(3, swordRank) : 0;
            level = 1;
            xp = 0;
            xpNeeded = 20;
            maxHp = 30 + (plus ? 5 : 0);
            hp = maxHp;
            maxMana = 10;
            mana = maxMana;
            gold = plus ? 12 : 0;
            shards = 0;
            potions = plus ? 3 : 2;
            swordRank = bonus;
            armorRank = plus ? Math.min(2, armorRank) : 0;
            victories = 0;
            region = 0;
            guarding = false;
            enemy = null;
            headline = "THE WHISPERING ROAD";
            message = "Collect five rune shards, grow stronger, and enter the ancient gate.";
            mode = MODE_WORLD;
            hasSave = true;
            saveGame();
            playTone(ToneGenerator.TONE_PROP_ACK, 110);
        }

        private void explore() {
            if (mode != MODE_WORLD) return;
            mana = Math.min(maxMana, mana + 1);
            float roll = random.nextFloat();
            if (roll < 0.62f) {
                startBattle(false);
            } else if (roll < 0.78f) {
                int found = randomInt(4, 9) + level;
                gold += found;
                headline = "FORGOTTEN CACHE";
                message = "You find " + found + " gold beneath a rock that was trying far too hard to look ordinary.";
                burst(getWidth() * 0.72f, getHeight() * 0.52f, C_GOLD, 18);
                showToast("Found " + found + " gold");
                playTone(ToneGenerator.TONE_PROP_BEEP2, 90);
            } else if (roll < 0.90f) {
                int healed = Math.min(maxHp - hp, randomInt(7, 14));
                hp += healed;
                mana = maxMana;
                headline = "MOONLIT SHRINE";
                message = healed > 0 ? "The shrine restores " + healed + " health and all of your mana."
                        : "The shrine restores your mana and compliments your excellent posture.";
                burst(getWidth() * 0.72f, getHeight() * 0.48f, C_BLUE, 22);
                showToast("Shrine blessing");
            } else {
                potions++;
                headline = "NERVOUS ALCHEMIST";
                message = "A traveling alchemist gives you a potion, refuses to explain why, and sprints into the woods.";
                showToast("Potion acquired");
                burst(getWidth() * 0.72f, getHeight() * 0.50f, C_GREEN, 16);
            }
            updateRegion();
            saveGame();
        }

        private void startBattle(boolean boss) {
            if (boss) {
                region = 3;
                enemy = new Enemy("THE HOLLOW KING", 5,
                        62 + level * 6, 10 + level + armorRank / 2,
                        70, 35, 48, level + 2, true,
                        "A crown of black flame hangs above his empty armor.");
                headline = "THE RUNE GATE OPENS";
                message = "The Hollow King rises from his throne. Finish what the old heroes could not.";
            } else {
                int maxType = Math.min(4, 1 + victories / 3);
                int type = randomInt(0, maxType);
                String[] names = {"MOSS SLIME", "MOONFANG WOLF", "LANTERN GOBLIN", "GRAVE WRAITH", "STONEBACK GOLEM"};
                String[] desc = {
                        "A furious lump of enchanted pond water blocks your path.",
                        "Its teeth glow with stolen rune-light.",
                        "A tiny bandit approaches, carrying an extremely large spoon.",
                        "It whispers several prophecies, none of them useful.",
                        "A walking boulder with unresolved anger issues stomps closer."
                };
                int[] baseHp = {13, 18, 23, 28, 35};
                int[] baseAtk = {4, 6, 7, 9, 11};
                int[] baseXp = {8, 11, 15, 19, 24};
                float scale = 1f + (level - 1) * 0.16f;
                enemy = new Enemy(names[type], type,
                        Math.round(baseHp[type] * scale),
                        Math.max(2, Math.round(baseAtk[type] * scale) - armorRank),
                        Math.round(baseXp[type] * scale),
                        3 + type * 2, 7 + type * 3,
                        level, false, desc[type]);
                headline = "MONSTER ENCOUNTER";
                message = desc[type];
            }
            guarding = false;
            mode = MODE_BATTLE;
            playTone(ToneGenerator.TONE_PROP_NACK, 100);
        }

        private void attack() {
            if (mode != MODE_BATTLE || enemy == null) return;
            int damage = randomInt(5 + level + swordRank * 2,
                    9 + level * 2 + swordRank * 3);
            boolean critical = random.nextFloat() < 0.13f + swordRank * 0.015f;
            if (critical) damage *= 2;
            enemy.hp -= damage;
            heroAttack = 1f;
            shake = 8f;
            flash = 0.15f;
            floatingTexts.add(new FloatingText("-" + damage + (critical ? " CRIT" : ""),
                    getWidth() * 0.72f, getHeight() * 0.43f, critical ? C_GOLD : Color.WHITE, 20f));
            burst(getWidth() * 0.70f, getHeight() * 0.48f, critical ? C_GOLD : C_RED, 12);
            playTone(ToneGenerator.TONE_PROP_BEEP, 55);
            resolveTurn();
        }

        private void castSpell() {
            if (mode != MODE_BATTLE || enemy == null) return;
            if (mana < 3) {
                showToast("Not enough mana");
                return;
            }
            mana -= 3;
            int damage = randomInt(10 + level * 2, 15 + level * 3) + swordRank;
            boolean critical = random.nextFloat() < 0.18f;
            if (critical) damage *= 2;
            enemy.hp -= damage;
            heroAttack = 1f;
            flash = 0.35f;
            floatingTexts.add(new FloatingText("✦ " + damage + (critical ? "!" : ""),
                    getWidth() * 0.72f, getHeight() * 0.42f, C_BLUE, 22f));
            burst(getWidth() * 0.72f, getHeight() * 0.45f, C_BLUE, 24);
            playTone(ToneGenerator.TONE_DTMF_9, 90);
            resolveTurn();
        }

        private void guard() {
            if (mode != MODE_BATTLE || enemy == null) return;
            guarding = true;
            mana = Math.min(maxMana, mana + 2);
            headline = "BRACED";
            message = "You raise your shield, halve the next hit, and recover 2 mana.";
            playTone(ToneGenerator.TONE_PROP_ACK, 60);
            enemyTurn();
        }

        private void usePotion() {
            if (mode != MODE_BATTLE || enemy == null) return;
            if (potions <= 0) {
                showToast("No potions left");
                return;
            }
            if (hp >= maxHp) {
                showToast("Health is already full");
                return;
            }
            potions--;
            int healed = Math.min(maxHp - hp, 16 + level * 3);
            hp += healed;
            floatingTexts.add(new FloatingText("+" + healed, getWidth() * 0.25f,
                    getHeight() * 0.41f, C_GREEN, 21f));
            burst(getWidth() * 0.25f, getHeight() * 0.47f, C_GREEN, 18);
            headline = "POTION USED";
            message = "You recover " + healed + " health. It tastes strongly of mint and poor decisions.";
            playTone(ToneGenerator.TONE_PROP_ACK, 90);
            enemyTurn();
        }

        private void flee() {
            if (mode != MODE_BATTLE || enemy == null) return;
            if (enemy.boss) {
                showToast("The gate has sealed behind you");
                return;
            }
            if (random.nextFloat() < 0.66f) {
                String name = enemy.name;
                enemy = null;
                mode = MODE_WORLD;
                headline = "NARROW ESCAPE";
                message = "You escape from the " + titleCase(name) + " and preserve your heroic reputation through selective storytelling.";
                showToast("Escaped safely");
                saveGame();
            } else {
                headline = "ESCAPE FAILED";
                message = "You run directly into a shrub. The monster politely waits for you to return.";
                enemyTurn();
            }
        }

        private void resolveTurn() {
            if (enemy == null) return;
            if (enemy.hp <= 0) {
                winBattle();
            } else {
                enemyTurn();
            }
        }

        private void enemyTurn() {
            if (enemy == null || enemy.hp <= 0) return;
            int damage = randomInt(Math.max(1, enemy.attack - 2), enemy.attack + 2);
            if (guarding) {
                damage = Math.max(1, damage / 2);
                guarding = false;
                message = "Your guard absorbs part of the blow. You take " + damage + " damage.";
            } else {
                message = "The " + titleCase(enemy.name) + " strikes for " + damage + " damage.";
            }
            hp = Math.max(0, hp - damage);
            enemyAttack = 1f;
            shake = 12f;
            floatingTexts.add(new FloatingText("-" + damage, getWidth() * 0.25f,
                    getHeight() * 0.42f, C_RED, 21f));
            burst(getWidth() * 0.27f, getHeight() * 0.47f, C_RED, 10);
            playTone(ToneGenerator.TONE_PROP_NACK, 55);
            if (hp <= 0) {
                bestLevel = Math.max(bestLevel, level);
                mode = MODE_GAME_OVER;
                headline = "YOUR ADVENTURE ENDS";
                message = "You reached level " + level + " and recovered " + shards + " rune shards.";
                hasSave = false;
                prefs.edit().putBoolean("has_save", false).putInt("best_level", bestLevel).apply();
            } else {
                saveGame();
            }
        }

        private void winBattle() {
            Enemy defeated = enemy;
            int goldReward = randomInt(defeated.goldMin, defeated.goldMax);
            gold += goldReward;
            xp += defeated.xp;
            victories++;
            mana = Math.min(maxMana, mana + 2);
            enemy = null;
            mode = MODE_WORLD;
            headline = "VICTORY";
            message = "You earn " + defeated.xp + " XP and " + goldReward + " gold.";
            burst(getWidth() * 0.72f, getHeight() * 0.45f, C_GOLD, 30);
            playTone(ToneGenerator.TONE_PROP_ACK, 120);

            if (defeated.boss) {
                bestLevel = Math.max(bestLevel, level);
                mode = MODE_VICTORY;
                headline = "THE REALM IS SAVED";
                message = "The Hollow King falls, and dawn reaches the valley for the first time in a century.";
                hasSave = false;
                prefs.edit().putBoolean("has_save", false).putInt("best_level", bestLevel).apply();
                return;
            }

            float shardChance = 0.35f + Math.min(0.18f, level * 0.025f);
            if (shards < 5 && random.nextFloat() < shardChance) {
                shards++;
                headline = "RUNE SHARD RECOVERED";
                message += " The monster was carrying rune shard " + shards + " of 5.";
                showToast("Rune shard " + shards + "/5");
                burst(getWidth() * 0.52f, getHeight() * 0.53f, C_PURPLE, 26);
            }
            checkLevelUp();
            updateRegion();
            saveGame();
        }

        private void checkLevelUp() {
            while (xp >= xpNeeded) {
                xp -= xpNeeded;
                level++;
                xpNeeded = Math.round(xpNeeded * 1.45f);
                maxHp += 8;
                maxMana += 3;
                hp = maxHp;
                mana = maxMana;
                bestLevel = Math.max(bestLevel, level);
                headline = "LEVEL UP — " + level;
                message = "Your health and mana are fully restored. Monsters across the valley become noticeably less confident.";
                showToast("Level " + level + " reached");
                flash = 1f;
                burst(getWidth() * 0.25f, getHeight() * 0.45f, C_GOLD, 35);
            }
        }

        private void rest() {
            if (hp >= maxHp) {
                showToast("You are already fully rested");
                return;
            }
            if (gold < 8) {
                showToast("You need 8 gold");
                return;
            }
            gold -= 8;
            hp = maxHp;
            mana = maxMana;
            headline = "WARM CAMPFIRE";
            message = "You recover completely and dream about finding cheaper lodging.";
            burst(getWidth() * 0.73f, getHeight() * 0.5f, C_GOLD, 18);
            saveGame();
        }

        private void openShop() {
            mode = MODE_SHOP;
            headline = "BROM'S QUESTIONABLE ARMORY";
            message = "Brom promises every item is genuine. Brom also refuses to define genuine.";
        }

        private void buySword() {
            int cost = 12 + swordRank * 10;
            if (gold < cost) {
                showToast("You need " + cost + " gold");
                return;
            }
            gold -= cost;
            swordRank++;
            headline = "SWORD UPGRADED";
            message = "Your attacks now deal more damage. Brom bites the blade and nods approvingly.";
            playTone(ToneGenerator.TONE_PROP_ACK, 90);
            saveGame();
        }

        private void buyArmor() {
            int cost = 14 + armorRank * 11;
            if (gold < cost) {
                showToast("You need " + cost + " gold");
                return;
            }
            gold -= cost;
            armorRank++;
            maxHp += 4;
            hp += 4;
            headline = "ARMOR UPGRADED";
            message = "Your maximum health increases and enemy attacks become weaker.";
            playTone(ToneGenerator.TONE_PROP_ACK, 90);
            saveGame();
        }

        private void buyPotion() {
            if (gold < 6) {
                showToast("You need 6 gold");
                return;
            }
            gold -= 6;
            potions++;
            headline = "POTION PURCHASED";
            message = "Brom says the glowing is normal. You decide not to ask follow-up questions.";
            saveGame();
        }

        private void enterGate() {
            if (shards < 5) {
                showToast("Find all five rune shards first");
                return;
            }
            startBattle(true);
        }

        private void updateRegion() {
            if (shards >= 5) region = 2;
            else if (victories >= 7) region = 2;
            else if (victories >= 3) region = 1;
            else region = 0;
        }

        private void setWorldMessage() {
            headline = region == 0 ? "THE WHISPERING ROAD" :
                    region == 1 ? "THE MOON CAVES" : "THE DROWNED RUINS";
            message = shards >= 5 ? "All five shards answer the gate. The Hollow King is waiting."
                    : "Explore for monsters, treasure, shrines, and the remaining rune shards.";
        }

        private void burst(float x, float y, int color, int amount) {
            for (int i = 0; i < amount; i++) {
                float angle = random.nextFloat() * (float) Math.PI * 2f;
                float speed = 45f + random.nextFloat() * 150f;
                particles.add(new Particle(x, y,
                        (float) Math.cos(angle) * speed,
                        (float) Math.sin(angle) * speed - 30f,
                        0.35f + random.nextFloat() * 0.55f,
                        3f + random.nextFloat() * 5f, color));
            }
        }

        private void showToast(String value) {
            toast = value;
            toastUntil = System.currentTimeMillis() + 1350L;
        }

        private void playTone(int value, int duration) {
            try { tone.startTone(value, duration); } catch (RuntimeException ignored) { }
        }

        private int randomInt(int min, int max) {
            return min + random.nextInt(Math.max(1, max - min + 1));
        }

        private String titleCase(String value) {
            String lower = value.toLowerCase(Locale.US);
            StringBuilder out = new StringBuilder();
            boolean cap = true;
            for (char ch : lower.toCharArray()) {
                if (cap && Character.isLetter(ch)) {
                    out.append(Character.toUpperCase(ch));
                    cap = false;
                } else {
                    out.append(ch);
                    if (ch == ' ' || ch == '-') cap = true;
                }
            }
            return out.toString();
        }

        void saveGame() {
            if (!hasSave || mode == MODE_TITLE || mode == MODE_GAME_OVER || mode == MODE_VICTORY) return;
            prefs.edit()
                    .putBoolean("has_save", true)
                    .putInt("level", level)
                    .putInt("xp", xp)
                    .putInt("xp_needed", xpNeeded)
                    .putInt("hp", hp)
                    .putInt("max_hp", maxHp)
                    .putInt("mana", mana)
                    .putInt("max_mana", maxMana)
                    .putInt("gold", gold)
                    .putInt("shards", shards)
                    .putInt("potions", potions)
                    .putInt("sword", swordRank)
                    .putInt("armor", armorRank)
                    .putInt("victories", victories)
                    .putInt("best_level", Math.max(bestLevel, level))
                    .apply();
        }

        private void loadGame() {
            level = prefs.getInt("level", 1);
            xp = prefs.getInt("xp", 0);
            xpNeeded = prefs.getInt("xp_needed", 20);
            maxHp = prefs.getInt("max_hp", 30);
            hp = Math.max(1, prefs.getInt("hp", maxHp));
            maxMana = prefs.getInt("max_mana", 10);
            mana = prefs.getInt("mana", maxMana);
            gold = prefs.getInt("gold", 0);
            shards = prefs.getInt("shards", 0);
            potions = prefs.getInt("potions", 2);
            swordRank = prefs.getInt("sword", 0);
            armorRank = prefs.getInt("armor", 0);
            victories = prefs.getInt("victories", 0);
            bestLevel = prefs.getInt("best_level", level);
            enemy = null;
            guarding = false;
            hasSave = true;
            updateRegion();
            setWorldMessage();
        }

        boolean handleBack() {
            if (mode == MODE_SHOP) {
                mode = MODE_WORLD;
                setWorldMessage();
                return true;
            }
            if (mode != MODE_TITLE) {
                saveGame();
                mode = MODE_TITLE;
                hasSave = prefs.getBoolean("has_save", false);
                return true;
            }
            return false;
        }

        private static final class GameButton {
            final RectF rect;
            final String action;
            GameButton(RectF rect, String action) {
                this.rect = rect;
                this.action = action;
            }
        }

        private static final class Enemy {
            final String name;
            final int type;
            int hp;
            final int maxHp;
            final int attack;
            final int xp;
            final int goldMin;
            final int goldMax;
            final int level;
            final boolean boss;
            final String description;

            Enemy(String name, int type, int hp, int attack, int xp,
                  int goldMin, int goldMax, int level, boolean boss, String description) {
                this.name = name;
                this.type = type;
                this.hp = hp;
                this.maxHp = hp;
                this.attack = attack;
                this.xp = xp;
                this.goldMin = goldMin;
                this.goldMax = goldMax;
                this.level = level;
                this.boss = boss;
                this.description = description;
            }
        }

        private static final class Particle {
            float x, y, vx, vy, life;
            final float maxLife, size;
            final int color;
            Particle(float x, float y, float vx, float vy, float life, float size, int color) {
                this.x = x;
                this.y = y;
                this.vx = vx;
                this.vy = vy;
                this.life = life;
                this.maxLife = life;
                this.size = size;
                this.color = color;
            }
        }

        private static final class FloatingText {
            final String text;
            final float x, size, maxLife;
            float y, life;
            final int color;
            FloatingText(String text, float x, float y, int color, float size) {
                this.text = text;
                this.x = x;
                this.y = y;
                this.color = color;
                this.size = size;
                this.life = 0.9f;
                this.maxLife = 0.9f;
            }
        }
    }
}
