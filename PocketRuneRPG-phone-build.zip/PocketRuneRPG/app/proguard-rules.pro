# Pocket Rune RPG does not need custom shrinking rules.
