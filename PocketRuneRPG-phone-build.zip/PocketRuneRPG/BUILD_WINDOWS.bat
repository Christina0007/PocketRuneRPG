@echo off
setlocal
set GRADLE_VERSION=9.5.1
set PROJECT_DIR=%~dp0
set TOOLS_DIR=%PROJECT_DIR%.build-tools
set GRADLE_HOME=%TOOLS_DIR%\gradle-%GRADLE_VERSION%
set GRADLE_ZIP=%TOOLS_DIR%\gradle-%GRADLE_VERSION%-bin.zip

if not exist "%TOOLS_DIR%" mkdir "%TOOLS_DIR%"

if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo Downloading Gradle %GRADLE_VERSION%...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_ZIP%'"
  if errorlevel 1 goto :fail
  echo Extracting Gradle...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%GRADLE_ZIP%' '%TOOLS_DIR%'"
  if errorlevel 1 goto :fail
)

if "%ANDROID_HOME%"=="" if exist "%LOCALAPPDATA%\Android\Sdk" set ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk
if "%ANDROID_SDK_ROOT%"=="" set ANDROID_SDK_ROOT=%ANDROID_HOME%

if "%ANDROID_HOME%"=="" (
  echo.
  echo Android SDK not found.
  echo Install Android Studio, open it once, and install Android SDK Platform 36.
  echo Then run this file again.
  goto :fail
)

call "%GRADLE_HOME%\bin\gradle.bat" -p "%PROJECT_DIR%" assembleDebug
if errorlevel 1 goto :fail

echo.
echo SUCCESS!
echo APK: %PROJECT_DIR%app\build\outputs\apk\debug\app-debug.apk
explorer "%PROJECT_DIR%app\build\outputs\apk\debug"
pause
exit /b 0

:fail
echo.
echo Build did not complete. The easiest fallback is to open this folder in Android Studio,
echo let it install any requested SDK components, then use Build ^> Build APK(s).
pause
exit /b 1
