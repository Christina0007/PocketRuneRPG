#!/usr/bin/env bash
set -euo pipefail
GRADLE_VERSION=9.5.1
ROOT="$(cd "$(dirname "$0")" && pwd)"
TOOLS="$ROOT/.build-tools"
ZIP="$TOOLS/gradle-$GRADLE_VERSION-bin.zip"
GRADLE="$TOOLS/gradle-$GRADLE_VERSION/bin/gradle"
mkdir -p "$TOOLS"
if [[ ! -x "$GRADLE" ]]; then
  curl -L "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o "$ZIP"
  unzip -q -o "$ZIP" -d "$TOOLS"
fi
: "${ANDROID_HOME:=${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}}"
export ANDROID_HOME ANDROID_SDK_ROOT="$ANDROID_HOME"
"$GRADLE" -p "$ROOT" assembleDebug
echo "APK: $ROOT/app/build/outputs/apk/debug/app-debug.apk"
