# Build Pocket Rune RPG entirely on an Android phone

## Easiest method: GitHub Actions

This does not install a large Android compiler on your phone. GitHub builds the APK in the cloud, and you download the finished APK back to the phone.

### 1. Create a GitHub account

Open `github.com` in Chrome and sign in or create a free account.

### 2. Create an empty repository

1. Tap your profile picture.
2. Open **Your repositories**.
3. Tap **New**.
4. Name it `PocketRuneRPG`.
5. Choose **Private** if you do not want the source public.
6. Do not add a README, license, or `.gitignore`.
7. Tap **Create repository**.

### 3. Upload the project files

1. Extract this ZIP with the Files app or ZArchiver.
2. Open the extracted `PocketRuneRPG` folder.
3. On the empty GitHub repository page, tap **uploading an existing file**.
4. Upload the contents of the `PocketRuneRPG` folder, not the outer folder itself.
5. Make sure `.github/workflows/build-apk.yml` is included.
6. Commit the files.

GitHub's mobile uploader can be awkward with whole folders. If it refuses folder uploads, use the GitHub app, a mobile Git client, or switch Chrome to **Desktop site**.

### 4. Run the APK build

1. Open the repository's **Actions** tab.
2. Open **Build Pocket Rune RPG APK**.
3. Tap **Run workflow** and confirm.
4. Open the completed green workflow run.
5. Under **Artifacts**, download `PocketRuneRPG-APK`.
6. Extract the downloaded artifact ZIP. Inside is `app-debug.apk`.

### 5. Install the game

1. Tap `app-debug.apk`.
2. Android may ask you to allow Chrome or Files to install unknown apps.
3. Grant that permission only for the app you used to open the APK.
4. Install **Pocket Rune RPG**.

The APK is a debug build intended for personal testing. It is automatically signed by the Android build tools and can be installed directly on your phone.

## Alternative: compile locally on the phone

A phone-based Android IDE can also open this Gradle project and run `assembleDebug`, but the first setup requires several gigabytes of storage and is much more likely to hit compatibility or memory problems. The GitHub Actions method is recommended.
