# Pocket Rune RPG

A complete offline Android mini-RPG drawn with a custom native Canvas renderer. No ads, analytics, accounts, internet permission, external images, or third-party runtime libraries.

## What is included

- Animated portrait-mode pixel-art scenery and characters
- Slimes, wolves, goblins, wraiths, golems, and a final boss
- Attack, Arc Bolt, Guard, Potion, and Flee combat actions
- Random treasure, shrine, and alchemist encounters
- Five-rune-shard quest and unlockable Rune Gate
- XP, levels, sword upgrades, armor upgrades, potions, and gold
- Local autosaving and Continue support
- Original launcher icon

## Easiest build method

1. Install Android Studio.
2. Open this `PocketRuneRPG` folder as a project.
3. Let Android Studio install any requested Android SDK components.
4. Choose **Build > Build APK(s)**.
5. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.

The project targets Android 16 / API 36 and supports Android 8.0+ / API 26+.

## Windows helper

After Android Studio and Android SDK Platform 36 are installed, double-click `BUILD_WINDOWS.bat`. It downloads Gradle into this project folder and builds the debug APK.

## Linux/macOS helper

With Java and the Android SDK installed:

```bash
./BUILD_LINUX_MAC.sh
```

## Install on your phone

Copy `app-debug.apk` to the phone, tap it, and approve the Android prompt allowing installations from the app that opened the file. The debug APK is suitable for personal sideloading.

## Building entirely from an Android phone

See `BUILD_ON_ANDROID_PHONE.md`. The included GitHub Actions workflow can create the installable APK in the cloud without Android Studio.
